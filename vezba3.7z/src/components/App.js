import React from "react";

export class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      password: "",
      email: "",
    };
  }
  usernameChangeHandler = (event) => {
    this.setState({
      username: event.target.value,
    });
  };
  passwordChangeHandler = (event) => {
    this.setState({
      password: event.target.value,
    });
  };
  emailChangeHandler = (event) => {
    this.setState({
      email: event.target.value,
    });
  };
  render() {
    console.log(this.state);
    return (
      <div id="app">
        <h2>Hello</h2>

        <input
          type={"text"}
          name={"username"}
          placeholder={"Username"}
          value={this.state.username}
          onChange={this.usernameChangeHandler}
        />
        <br />
        <br />
        <input
          type={"password"}
          name={"password"}
          placeholder={"password"}
          value={this.state.password}
          onChange={this.passwordChangeHandler}
        />
        <br />
        <br />

        <input
          type={"text"}
          name={"email"}
          placeholder={"Enter your email here.."}
          value={this.state.email}
          onChange={this.emailChangeHandler}
        />
        <br />
        <br />

        <h2>Your username is: {this.state.username}</h2>
        <hr />
        <h2>Your password is: {this.state.password}</h2>
        <hr />
        <h2>This is your email: {this.state.email}</h2>
      </div>
    );
  }
}
